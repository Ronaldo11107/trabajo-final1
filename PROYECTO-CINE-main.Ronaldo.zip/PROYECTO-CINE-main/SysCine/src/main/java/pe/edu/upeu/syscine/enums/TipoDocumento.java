package pe.edu.upeu.syscine.enums;

public enum TipoDocumento {
    DNI,
    CE,
    RUC,
    PASAPORTE
}
