package pe.edu.upeu.syscine;

import javafx.application.Application;

public class App {
    public static void main(String[] args) {
        Application.launch(SysCine.class, args);
    }
}
