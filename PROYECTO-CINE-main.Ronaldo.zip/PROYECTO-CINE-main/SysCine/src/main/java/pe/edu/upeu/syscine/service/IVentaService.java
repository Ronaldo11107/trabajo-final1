package pe.edu.upeu.syscine.service;

import pe.edu.upeu.syscine.model.Venta;

public interface IVentaService extends ICrudGenericoService<Venta, Long>{
}
